import { OnboardingScreen } from '@/features/onboarding/onboarding-screen';

export default function Onboarding() {
  return <OnboardingScreen />;
}
