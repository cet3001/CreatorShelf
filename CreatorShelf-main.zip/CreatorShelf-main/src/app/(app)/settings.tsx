import { SettingsScreen } from '@/features/settings/settings-screen';

export default function Settings() {
  return <SettingsScreen />;
}
