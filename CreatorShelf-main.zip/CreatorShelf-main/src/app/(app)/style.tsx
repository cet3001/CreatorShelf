import { StyleScreen } from '@/features/style-demo/style-screen';

export default function Style() {
  return <StyleScreen />;
}
