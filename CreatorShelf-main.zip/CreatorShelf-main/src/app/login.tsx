import { LoginScreen } from '@/features/auth/login-screen';

export default function Login() {
  return <LoginScreen />;
}
