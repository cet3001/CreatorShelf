import { PostDetailScreen } from '@/features/feed/post-detail-screen';

export default function PostDetail() {
  return <PostDetailScreen />;
}
