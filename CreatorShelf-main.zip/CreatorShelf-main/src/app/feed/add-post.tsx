import { AddPostScreen } from '@/features/feed/add-post-screen';

export default function AddPost() {
  return <AddPostScreen />;
}
