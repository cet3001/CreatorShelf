module.exports = require('react-native-gesture-handler/src/mocks.ts');
