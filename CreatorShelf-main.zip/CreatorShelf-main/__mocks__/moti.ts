import { View } from 'react-native';

const AnimatePresence = View;
const MotiView = View;

module.exports = {
  AnimatePresence,
  View,
  MotiView,
};
