module.exports = require('@gorhom/bottom-sheet/mock');
